import boto3
import json

def enqueue_object(bucketname, s3_file_name, queueURL, sqs_client):
    payload = { 
    "bucketname": bucketname, 
    "s3_file_name": s3_file_name
    }
    str_payload = json.dumps(payload)
    
    response = sqs_client.send_message(
        QueueUrl=queueURL,
        DelaySeconds=1,
        # MessageAttributes=,
        MessageBody=str_payload        
        # MessageBody=(
        #     'Information about current NY Times fiction bestseller for '
        #     'week of 12/11/2016.'
        # )
    )

    print(response['MessageId'])




sqs_client = boto3.client('sqs')
QUEUEURL = "https://sqs.us-west-2.amazonaws.com/696965430582/Amazon-S3-Bucket-Load-Test-EcsTaskSqsQueue-XM8WG11LWBDL"
BUCKETNAME = "s3-bucket-load-test-storagebucket-knlgpd3wpz0n"
s3_file_name = 'test.txt'

enqueue_object(BUCKETNAME, s3_file_name, QUEUEURL, sqs_client)



# https://boto3.amazonaws.com/v1/documentation/api/latest/guide/sqs.html



# {
#             'bucketname': {
#                 'DataType': 'String',
#                 'StringValue': bucketname
#             },
#             's3_file_name': {
#                 'DataType': 'String',
#                 'StringValue': s3_file_name
#             }
#         }